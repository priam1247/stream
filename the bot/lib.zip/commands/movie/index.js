/**
 * ZaFar Bot — .movie  (download a movie)
 *
 *   .movie <title> [year] [480|720|1080|2160]
 *
 * Quiet by design: the only chat messages are the numbered picker (only when a
 * title is ambiguous), the finished file, and ONE short line if something goes
 * wrong. Everything else is a reaction (⏳ → ✅ / ❌), like the rest of the bot.
 */

const fs = require('fs');
const path = require('path');
const config = require('../../config');
const engine = require('../../lib/movies/adapter');
const selections = require('../../lib/selections');
const host = require('../../lib/movies/host');
const { getTempDir, createTempFilePath, deleteTempFile, holdTemp } = require('../../lib/tempManager');
const diskSpace = require('../../lib/diskSpace');
const { safeErrorMessage } = require('../../lib/userErrors');
const { minPlaySeconds, assertFullLength } = require('../../lib/movies/length');
const logger = require('../../lib/logger');
const log = logger('movie');

const QUALITY_RX = /^(480|720|1080|2160|4k)$/i;
const MOVIES = () => config.movies || {};

const qualityOf = (token) => {
  const t = String(token || '').toLowerCase();
  if (t === '4k') return 2160;
  return Number(t);
};

function parseArgs(args) {
  const rest = [];
  // default quality follows the bot: config.movies → media settings → config.video
  let quality = MOVIES().defaultQuality || host.defaultQuality();
  let explicitQuality = false;

  for (const a of args) {
    if (QUALITY_RX.test(a)) { quality = qualityOf(a); explicitQuality = true; continue; }
    rest.push(a);
  }

  const text = rest.join(' ').trim();

  // Pick the last plausible year that still leaves a title behind, so films
  // whose name IS a year ("1917", "2012") keep it.
  let year = null;
  let title = text;
  const yearTokens = [...text.matchAll(/\b((?:19|20)\d{2})\b/g)].map(m => m[1]);
  for (const y of yearTokens.reverse()) {
    const without = text.replace(new RegExp(`\\b${y}\\b`), '').replace(/\s+/g, ' ').trim();
    if (without) {
      year = y;
      title = without;
      break;
    }
  }

  return { title, year, quality, explicitQuality };
}

const help = (P) => `Usage: ${P}movie <title> [year] [480|720|1080|2160]`;

/** Safe error summary for chat — never forwards raw internal error text. */
const shortError = (e, extra) =>
  safeErrorMessage(e, {
    isOwner: Boolean(extra?.isOwner),
    fallback: '❌ Could not search movie sources right now. Please try again shortly.',
  });

/**
 * Resolve + download, retrying with the failed provider excluded.
 * One dead CDN link used to end the command; now the engine walks on to the
 * next source instead of telling the user "no source".
 */
async function fetchSource(meta, quality, attempts = 3) {
  const exclude = [];
  let lastErr = null;

  for (let i = 0; i < attempts; i++) {
    const resolved = await engine.resolveMovie({
      item: meta, tmdbId: meta.tmdbId, title: meta.title, year: meta.year, quality, exclude,
    });

    if (MOVIES().dryRun) return { res: resolved, file: null };

    const sizeMB = Number(resolved.sizeMB) || 0;
    if (sizeMB && sizeMB > host.maxDownloadMB()) return { res: resolved, file: null, tooBig: sizeMB };

    if (resolved.kind === 'cache' && resolved.file && fs.existsSync(resolved.file)) {
      return { res: resolved, file: resolved.file, cached: true };
    }

    const dest = await engine.targetFile(meta.title, meta.year, quality, null, null);
    let downloadedFile = dest;
    const reservation = diskSpace.reserveMovieSpace(getTempDir(), resolved.sizeMB, MOVIES(), {
      label: `movie:${meta.title}`,
      tagDir: path.dirname(dest),
      tagPrefix: path.basename(dest, path.extname(dest)),
    });
    const releaseHold = holdTemp(path.basename(dest, path.extname(dest)));
    try {
      const saved = await engine.download(resolved, dest);
      // HLS sources may land as .ts (no ffmpeg on the host) — use the real path
      const file = downloadedFile = (saved && saved.file) || dest;
      const full = resolved.meta || meta;
      await assertFullLength(file, full.runtime, 'movie');
      return { res: resolved, file, reservation, releaseHold };
    } catch (e) {
      reservation.release();
      releaseHold();
      lastErr = e;
      log.warn(`${meta.title} ${quality}p · ${resolved.provider} download failed · ${e.message}`);
      exclude.push(resolved.provider);
      for (const f of new Set([downloadedFile, dest, dest.replace(/\.(mp4|mkv|ts|m4v)$/i, '') + '.ts'])) {
        try { fs.rmSync(f, { force: true }); } catch { /* ignore */ }
      }
      if (exclude.length >= attempts) break;
    }
  }
  throw lastErr || new Error('no downloadable source found');
}

/**
 * Offer title choices via WhatsApp's native tap-to-select drawer (`single_select`),
 * falling back automatically to Poll or numbered text when needed.
 */
async function offerChoices(sock, msg, extra, matches, job, kind) {
  const optionLabels = matches.map((m) => {
    const year = m.year ? ` (${m.year})` : '';
    const rating = Number(m.rating) ? ` ⭐${m.rating}` : '';
    return `${m.title}${year}${rating}`;
  });
  const lines = optionLabels.map((lbl, i) => `*${i + 1}.* ${lbl}`);
  const isSeries = kind === 'series';
  const header = `🎬 *${matches.length} ${isSeries ? 'series' : 'movies'}* for *${job.title}*`;
  const fallbackText = `${header}\n\n${lines.join('\n')}\n\n_Reply ${config.prefix}1–${config.prefix}${matches.length}_`;

  await selections.sendPollOrText(sock, msg, extra, {
    pollName: `${header}\nTap a title:`,
    optionLabels,
    fallbackText,
    selector: {
      headerTitle: `🎬 ${job.title}`,
      bodyText: `${matches.length} matches found — tap below to select:`,
      footerText: 'Movies',
      buttonText: isSeries ? 'Select Series' : 'Select Movie',
      sectionTitle: isSeries ? 'Matching Series' : 'Matching Movies',
      rows: matches.map((m, idx) => ({
        title: `${idx + 1}. ${m.title}`,
        description: [m.year ? String(m.year) : null, Number(m.rating) ? `⭐ ${m.rating}` : null]
          .filter(Boolean)
          .join(' · '),
      })),
    },
    items: matches,
    label: kind,
    ttlMs: 5 * 60 * 1000,
    run: (sock2, msg2, extra2, item) => askQuality(sock2, msg2, extra2, item, { ...job }),
  });
}

const fmtSize = (mb) => (mb >= 1024 ? `${(mb / 1024).toFixed(1)} GB` : `${Math.round(mb)} MB`);

/**
 * Ask which quality to fetch via native tap selector (with real size & provider).
 */
async function askQuality(sock, msg, extra, meta, job) {
  const react = (emoji) =>
    msg?.key ? sock.sendMessage(extra.from, { react: { text: emoji, key: msg.key } }).catch(() => {}) : Promise.resolve();

  if (job.explicitQuality) return deliver(sock, msg, extra, meta, job);

  await react('🔎');
  let options = [];
  try {
    const found = await engine.qualityOptions({
      item: meta, season: job.season ?? null, episode: job.episode ?? null,
    });
    options = found.options || [];
  } catch (e) {
    log.debug(`${meta.title} · quality probe failed · ${e.message}`);
  }

  if (!options.length) return deliver(sock, msg, extra, meta, job);   // nothing to choose from
  if (options.length === 1) { job.quality = options[0].quality; return deliver(sock, msg, extra, meta, job); }

  const ids = options.map((o) => `q${o.quality}`);
  const items = options.map((o) => ({ ...o, meta }));
  const title = `${meta.title}${meta.year ? ` (${meta.year})` : ''}`;
  const header = `🎬 *${title}*\nChoose quality:`;
  const optionLabels = options.map((o) => `${o.quality}p${o.sizeMB ? ` · ~${fmtSize(o.sizeMB)}` : ''}`);
  const lines = optionLabels.map((lbl, i) => `*${i + 1}.* ${lbl}`);

  await selections.sendPollOrText(sock, msg, extra, {
    pollName: header,
    optionLabels,
    fallbackText: `${header}\n\n${lines.join('\n')}\n\n_Reply ${config.prefix}1–${config.prefix}${options.length}_`,
    selector: {
      headerTitle: `🎬 ${title}`,
      bodyText: 'Select download quality:',
      footerText: 'Movies',
      buttonText: 'Select Quality',
      sectionTitle: 'Available Qualities',
      rows: options.map((o) => ({
        title: `${o.quality}p`,
        description: [o.sizeMB ? `~${fmtSize(o.sizeMB)}` : null, o.provider || null]
          .filter(Boolean)
          .join(' · '),
      })),
    },
    items,
    ids,
    label: 'quality',
    ttlMs: 5 * 60 * 1000,
    run: (sock2, msg2, extra2, item) => {
      job.quality = item.quality;
      return deliver(sock2, msg2, extra2, meta, job);
    },
  });
}

/**
 * Attach the subtitle track that came with the stream (MovieBox serves it).
 * Best effort and silent: a missing subtitle never fails the download.
 */
async function trySubtitles(sock, chatId, msg, meta, { season = null, episode = null } = {}) {
  if ((MOVIES().subtitles ?? true) === false) return null;
  const lang = MOVIES().subtitleLang || 'en';
  const base = season != null
    ? `${meta.title} S${String(season).padStart(2, '0')}E${String(episode).padStart(2, '0')}`
    : `${meta.title}${meta.year ? ` (${meta.year})` : ''}`;
  const dest = createTempFilePath('movie_sub', 'srt');
  const releaseHold = holdTemp(path.basename(dest, '.srt'));
  let sub = null;

  try {
    sub = await engine.subtitles(meta, { season, episode, lang, dest });
    if (!sub?.file || !fs.existsSync(sub.file)) return null;
    await host.sendSubtitle(sock, chatId, msg, { file: sub.file, name: base, language: sub.language || lang });
    log.info(`${base} · subtitle ${sub.language || lang}`);
    return sub;
  } catch (e) {
    log.debug(`${base} · no subtitle (${e.message})`);
    return null;
  } finally {
    deleteTempFile(sub?.file);
    deleteTempFile(dest);
    deleteTempFile(dest.replace(/\.srt$/i, '.vtt'));
    releaseHold();
  }
}

/** Resolve → download → send. One file message, reactions for the rest. */
async function deliver(sock, msg, extra, meta, job) {
  const chatId = extra.from;
  const quality = job.quality;
  const react = (emoji) =>
    msg?.key ? sock.sendMessage(chatId, { react: { text: emoji, key: msg.key } }).catch(() => {}) : Promise.resolve();
  const say = (text) => sock.sendMessage(chatId, { text }, selections.quoteOpts(msg));

  await react('⏳');
  let activeReservation = null;
  let activeFile = null;
  let activeHold = null;

  try {
    // Start immediately; disk reservations protect concurrent downloads.
    log.debug(`${meta.title}${meta.year ? ` (${meta.year})` : ''} · ${quality}p · start`);
    const t0 = Date.now();
    const jobResult = await engine.enqueue(
      chatId,
      `movie ${meta.title} ${quality}p`,
      () => fetchSource(meta, quality),
      { timeoutMs: MOVIES().jobTimeoutMs }
    );

    const { res, file, reservation, releaseHold } = jobResult;
    activeReservation = reservation || null;
    activeHold = releaseHold || null;
    activeFile = file || null;

    if (MOVIES().dryRun) {
      await react('🔗');
      return say(`🔗 ${meta.title}\n${res.url || '(cached)'}`);
    }
    if (jobResult.tooBig) {
      await react('❌');
      return say(`❌ *${meta.title}* is ${jobResult.tooBig.toFixed(0)} MB — over the ${host.maxDownloadMB()} MB download cap.`);
    }

    log.info(`${meta.title} · ${res.provider} · ${res.quality || quality}p · ` +
      `${host.fmtMB(fs.statSync(file).size)} · ${Math.round((Date.now() - t0) / 1000)}s`);

    const shownQuality = res.quality || quality;
    const note = res.downgraded ? ` (${shownQuality}p)` : '';
    await host.deliver(sock, chatId, msg, {
      file,
      title: meta.title,
      caption: `🎬 *${meta.title}${meta.year ? ` (${meta.year})` : ''}*\n${shownQuality}p${note} · ${host.fmtMB(fs.statSync(file).size)}`,
    });

    await trySubtitles(sock, chatId, msg, meta);
    await host.release(file).catch(() => false);
    activeFile = null;
    await react('✅');
    require('../../lib/telemetry').recordDownloadSuccess('movie');
  } catch (e) {
    require('../../lib/telemetry').recordFailure('movie');
    log.error(`${meta.title}${meta.year ? ` (${meta.year})` : ''} · ${e.code || 'FAIL'} · ${e.message}`);
    await react('❌');
    const alts = await engine.alternatives(job.matches, { chosen: meta }).catch(() => []);
    const matched = `*${meta.title}*${meta.year ? ` (${meta.year})` : ''}`;
    const hint = alts.length
      ? `\n💡 Did you mean *${alts[0].title}*${alts[0].year ? ` (${alts[0].year})` : ''}?`
      : '';
    if (e.code === 'SHORT' || /trailer\/fake/.test(String(e.message))) {
      return say(`❌ No full-length source for ${matched} yet.`);
    }
    if (e.code === 'NOT_ENOUGH_DISK') {
      return say(safeErrorMessage(e, { isOwner: Boolean(extra?.isOwner) }));
    }
    await say(`❌ No source for ${matched}.${hint}`);
  } finally {
    if (activeFile) await host.release(activeFile).catch(() => false);
    activeReservation?.release?.();
    activeHold?.();
  }
}

module.exports = {
  name: 'movie',
  timeoutMs: 3 * 60 * 60 * 1000, // large downloads legitimately run for a long time
  aliases: ['film', 'mv'],
  category: 'media',
  description: 'Download a movie',
  usage: '.movie <title> [year] [quality]',

  async execute(sock, msg, args, extra) {
    const P = config.prefix;
    if (!args.length) return extra.reply(help(P));

    const job = parseArgs(args);
    if (!job.title) return extra.reply(help(P));

    try {
      const matches = await engine.searchMovie(job.title, job.year || undefined);
      if (!matches.length) return extra.reply(`❌ No movie found for *${job.title}*.`);

      // Exact single hit (or an explicit year) → choose the quality next.
      if (matches.length === 1 || job.year) {
        const best = (job.year && matches.find(m => String(m.year) === String(job.year))) || matches[0];
        job.matches = matches;
        return askQuality(sock, msg, extra, best, job);
      }

      // A vague title matches many films: show them all instead of grabbing #1.
      job.matches = matches;
      return offerChoices(sock, msg, extra, matches, job, 'movie');
    } catch (e) {
      log.error(`${job.title || 'search'} · ${e.code || 'FAIL'} · ${String(e.message).split('\n')[0]}`);
      return extra.reply(shortError(e, extra));
    }
  },

  // exported for tests
  _parseArgs: parseArgs,
  _minPlaySeconds: minPlaySeconds,
  _assertFullLength: assertFullLength,
  _deliver: deliver,
  _offerChoices: offerChoices,
  _askQuality: askQuality,
};
